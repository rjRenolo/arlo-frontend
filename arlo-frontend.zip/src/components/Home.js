import React from 'react';
import setState from 'react';
import state from 'react';
import { Component } from "react";
import $ from 'jquery';
import { BrowserRouter, Route, Link, Switch } from "react-router-dom";
import { Store, set, get} from 'idb-keyval';
import { Offline, Online } from "react-detect-offline";

// const consultantStore = new Store('consultant-store');

export class Home extends React.Component {

  constructor(props){
       super(props);

    //    this.state = {}

  }

  componentDidMount = () => {


  }

  componentDidUpdate = () => {
    
  }


  render() {


    return (
      <div className="wrapper">

        

      </div>
    );

  }
  
}

export default Home;
